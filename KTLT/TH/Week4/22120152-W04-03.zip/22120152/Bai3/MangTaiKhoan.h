#pragma once
#include"TaiKhoan.h"
void nhapMang(TaiKhoan*& x, int n);
void xuatMang(TaiKhoan* x, int n);